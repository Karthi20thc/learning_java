package dev.lpa;

import com.abc.first.*;

public class Main {

    public static void main(String[] args) {

        Item firstItem = new com.abc.first.Item("Burger");
        System.out.println(firstItem);
    }
}
